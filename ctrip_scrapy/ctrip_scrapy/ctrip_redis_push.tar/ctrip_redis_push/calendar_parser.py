from parser import Parser
from pymysql.err import InterfaceError
import json

class CalendarParser(Parser):
    def run(self):
        sql = "SELECT id, house_id, response FROM house_calendar_response WHERE status=0 AND parse_status=0"
        self.cursor.execute(sql)
        rows = self.cursor.fetchall()

        data = []
        ids = []
        for r in rows:
            try:
                house_id = r['house_id']
                response = json.loads(r['response'])
                _result = json.loads(response['result'])
                house_cals = _result['data']['houseCalendars']
                if isinstance(house_cals, list):
                    for hc in house_cals:
                        house_date_key = house_id + "_" + hc['date']
                        booked = 0 if hc['canBooking'] == 1 else 1

                        data_for_placehold = (house_date_key, house_id, hc['date'], hc['price'], booked, hc['price'],
                                              booked)
                        hc_sql = "INSERT INTO house_cals " \
                                 "(house_date_key, house_id, cal_date, price, booked) VALUES " \
                                 "(%s, %s, %s, %s, %s) ON DUPLICATE KEY UPDATE " \
                                 "price=%s, booked=%s"
                        self.cursor.execute(hc_sql, data_for_placehold)
                self.db.commit()
            except InterfaceError as e:
                self.handle_db_timeout(sql, data, e)
            except Exception as e:
                self.logger.exception(e)
                self.db.rollback()
            else:
                update_sql = "UPDATE house_calendar_response SET parse_status=1 WHERE id=%s"
                self.cursor.execute(update_sql, (r['id'],))
                # format_strings = ','.join(['%s'] * len(ids))
                # update_sql = "UPDATE house_calendar_response SET parse_status=1 WHERE id IN (%s)" % format_strings
                # self.cursor.execute(update_sql, tuple(ids))
                self.db.commit()

if __name__ == "__main__":
    parser = CalendarParser()
    parser.run()